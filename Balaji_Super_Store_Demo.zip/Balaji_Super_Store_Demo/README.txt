BALAJI SUPER STORE DEMO

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge.
3. Enter any valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.
4. Place a test order and save its tracking code.
5. Admin: click Admin Login and enter RARIA321.

Important limitations:
- This is a shareable front-end demo, not a live multi-device store.
- Orders are stored in this browser only and do not automatically sync to other devices.
- The demo password is visible in the JavaScript source. Anyone with the file can inspect it.
- For a real public store, connect Supabase and verify admin access securely on the server. Never put Supabase service_role keys in browser code.
